package com.example.demo.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "users")
@SuppressWarnings("unused")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @SuppressWarnings("unused")
    private Long id;

    @NotBlank(message = "username required")
    @Column(nullable = false)
    private String username;

    @Email(message = "invalid email")
    @Column(nullable = false, unique = true)
    private String email;

    @NotBlank(message = "password required")
    @Column(nullable = false)
    private String password;

    @Column(name = "carbon_balance", nullable = false)
    private Double carbonBalance = 0.0;

    public User() {}

    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Double getCarbonBalance() {
        return carbonBalance;
    }

    public void setCarbonBalance(Double carbonBalance) {
        this.carbonBalance = carbonBalance;
    }
}
