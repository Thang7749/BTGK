package com.example.demo.service;

import com.example.demo.entity.Co2Reduction;
import com.example.demo.repository.Co2Repository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class Co2Service {

    private final Co2Repository co2Repository;

    @Transactional
    public String processEmission(double baseline, double actual, boolean certified, Long userId) {
        log.info("Processing CO2 emission for user ID: {}, baseline: {}, actual: {}, certified: {}", 
                userId, baseline, actual, certified);
        
        // Validate input parameters
        if (baseline <= 0 || actual < 0) {
            return "Dữ liệu không hợp lệ: baseline phải > 0 và actual phải >= 0.";
        }
        
        if (baseline < actual) {
            return "Dữ liệu không hợp lệ: phát thải thực tế lớn hơn cơ sở.";
        }

        double reduction = baseline - actual;
        
        String status;
        if (reduction < 1000) {
            status = "REJECTED";
        } else if (!certified) {
            status = "REJECTED";
        } else {
            status = "APPROVED";
        }

        Co2Reduction record = new Co2Reduction();
        record.setUserId(userId.toString());
        record.setBaseline(baseline);
        record.setActual(actual);
        record.setReduction(reduction);
        record.setCertified(certified);
        record.setStatus(status);
        
        Co2Reduction savedRecord = co2Repository.save(record);
        log.info("CO2 reduction record saved with ID: {}, status: {}", savedRecord.getId(), status);

        return "Kết quả: " + status + " (Giảm " + String.format("%.2f", reduction) + " kg CO2)";
    }
}
