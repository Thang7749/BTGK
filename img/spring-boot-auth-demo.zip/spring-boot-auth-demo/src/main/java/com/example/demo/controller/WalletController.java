package com.example.demo.controller;

import com.example.demo.entity.WalletTransaction;
import com.example.demo.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/wallet")
public class WalletController {

    private final WalletService walletService;

    @Autowired
    public WalletController(WalletService walletService) {
        this.walletService = walletService;
    }

    /**
     * Get current carbon balance for a user
     * @param userId The user's ID
     * @return Current carbon balance
     */
    @GetMapping("/{userId}/balance")
    public ResponseEntity<?> getBalance(@PathVariable Long userId) {
        try {
            Double balance = walletService.getBalance(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("userId", userId);
            response.put("carbonBalance", balance);

            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Credit carbon credits to a user's wallet
     * @param userId The user's ID
     * @param amount The amount to credit
     * @param description Optional transaction description
     * @return The created transaction
     */
    @PostMapping("/{userId}/credit")
    public ResponseEntity<?> credit(
            @PathVariable Long userId,
            @RequestParam Double amount,
            @RequestParam(required = false, defaultValue = "Carbon credit added") String description) {
        try {
            WalletTransaction transaction = walletService.credit(userId, amount, description);
            return ResponseEntity.status(HttpStatus.CREATED).body(transaction);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Debit carbon credits from a user's wallet
     * @param userId The user's ID
     * @param amount The amount to debit
     * @param description Optional transaction description
     * @return The created transaction
     */
    @PostMapping("/{userId}/debit")
    public ResponseEntity<?> debit(
            @PathVariable Long userId,
            @RequestParam Double amount,
            @RequestParam(required = false, defaultValue = "Carbon credit deducted") String description) {
        try {
            WalletTransaction transaction = walletService.debit(userId, amount, description);
            return ResponseEntity.status(HttpStatus.CREATED).body(transaction);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        }
    }
}
