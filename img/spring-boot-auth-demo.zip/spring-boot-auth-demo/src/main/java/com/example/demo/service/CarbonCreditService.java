package com.example.demo.service;

import com.example.demo.entity.CarbonCredit;
import com.example.demo.entity.CreditRequest;
import com.example.demo.repository.CarbonCreditRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarbonCreditService {

    private final CarbonCreditRepository carbonCreditRepository;

    @Autowired
    public CarbonCreditService(CarbonCreditRepository carbonCreditRepository) {
        this.carbonCreditRepository = carbonCreditRepository;
    }

    // Issue a carbon credit after request approval
    public CarbonCredit issueCredit(CreditRequest request) {
        CarbonCredit credit = new CarbonCredit();
        Long ownerId = null;
        Double amount = null;
        String source = null;

        // Lấy ownerId hoặc userId từ CreditRequest
        try {
            ownerId = (Long) CreditRequest.class.getMethod("getOwnerId").invoke(request);
        } catch (Exception e) {
            try {
                ownerId = (Long) CreditRequest.class.getMethod("getUserId").invoke(request);
            } catch (Exception ex) {
                throw new RuntimeException("CreditRequest missing getOwnerId() or getUserId()");
            }
        }

        // Lấy carbon amount
        try {
            amount = (Double) CreditRequest.class.getMethod("getCarbonAmount").invoke(request);
        } catch (Exception e) {
            throw new RuntimeException("CreditRequest missing getCarbonAmount()");
        }

        // Lấy request id để ghi nguồn
        try {
            Object requestIdObj = CreditRequest.class.getMethod("getId").invoke(request);
            source = "Request#" + String.valueOf(requestIdObj);
        } catch (Exception e) {
            source = "Request#?";
        }

        // Gán thông tin vào credit
        // ⚙️ Kiểm tra xem entity có setOwnerId hay setUserId
        try {
            CarbonCredit.class.getMethod("setOwnerId", Long.class).invoke(credit, ownerId);
        } catch (NoSuchMethodException e) {
            try {
                CarbonCredit.class.getMethod("setUserId", Long.class).invoke(credit, ownerId);
            } catch (NoSuchMethodException ex) {
                throw new RuntimeException("CarbonCredit entity missing setOwnerId(Long) or setUserId(Long)");
            } catch (Exception ex) {
                throw new RuntimeException("Could not set owner/user id on CarbonCredit: " + ex.getMessage());
            }
        } catch (Exception e) {
            throw new RuntimeException("Could not set ownerId on CarbonCredit: " + e.getMessage());
        }

        // Gán amount và source
        credit.setAmount(amount);
        credit.setSource(source);

        // Đặt trạng thái chưa niêm yết
        try {
            CarbonCredit.class.getMethod("setListed", boolean.class).invoke(credit, false);
        } catch (NoSuchMethodException e) {
            // Nếu entity chưa có setListed, bỏ qua
        } catch (Exception e) {
            throw new RuntimeException("Could not set 'listed' status on CarbonCredit: " + e.getMessage());
        }

        return carbonCreditRepository.save(credit);
    }

    public List<CarbonCredit> getCreditsByOwner(Long ownerId) {
        return carbonCreditRepository.findByOwnerId(ownerId);
    }

    public List<CarbonCredit> getListedCredits() {
        return carbonCreditRepository.findByListedTrue();
    }

    public CarbonCredit listCredit(Long creditId) {
        CarbonCredit credit = carbonCreditRepository.findById(creditId)
                .orElseThrow(() -> new RuntimeException("Credit not found"));
        try {
            CarbonCredit.class.getMethod("setListed", boolean.class).invoke(credit, true);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("CarbonCredit entity does not have a 'setListed(boolean)' method.");
        } catch (Exception e) {
            throw new RuntimeException("Could not set 'listed' status on CarbonCredit: " + e.getMessage());
        }
        return carbonCreditRepository.save(credit);
    }

    public CarbonCredit unlistCredit(Long creditId) {
        CarbonCredit credit = carbonCreditRepository.findById(creditId)
                .orElseThrow(() -> new RuntimeException("Credit not found"));
        try {
            CarbonCredit.class.getMethod("setListed", boolean.class).invoke(credit, false);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("CarbonCredit entity does not have a 'setListed(boolean)' method.");
        } catch (Exception e) {
            throw new RuntimeException("Could not set 'listed' status on CarbonCredit: " + e.getMessage());
        }
        return carbonCreditRepository.save(credit);
    }
}
